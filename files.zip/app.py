"""
Card statement categoriser — a loop-engineering project.

Goal:     produce a keyword rulebook that categorises transaction narrations.
Verifier: accuracy on a labelled CSV. Pure Python. Costs zero tokens.
Exits:    accuracy >= TARGET | no-progress | step cap.

The important idea: the loop's OUTPUT is a rulebook, not an answer. Once the
loop finishes, categorising a new transaction runs the rulebook and calls no
model at all. You pay tokens once to build the artifact, then zero forever.

Token discipline:
  - Each iteration builds a FRESH prompt. No growing transcript, so cost per
    step stays flat instead of compounding.
  - The model never sees the whole dataset. Step 1 sees 6 sample narrations;
    later steps see only the rows the current rulebook got wrong, capped at 6.
  - Scoring all 38 rows costs nothing, so the expensive part is the cheap part.
"""

import csv
import json
import os

import anthropic
from fastapi import FastAPI
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

MODEL = "claude-haiku-4-5-20251001"
MAX_STEPS = 5
MAX_TOKENS = 700
TARGET = 0.95

CATEGORIES = ["Food", "Groceries", "Transport", "Shopping", "Bills",
              "Entertainment", "Travel", "Fuel", "Health", "Fees"]

SYSTEM = (
    "You write keyword rules for classifying bank transaction narrations. "
    'Output only a JSON array: [{"keyword": "SWIGGY INSTAMART", "category": "Groceries"}]. '
    "Rules are matched in order, first hit wins, so put specific keywords before "
    "general ones. No prose, no code fences."
)

client = anthropic.Anthropic(api_key=os.environ["ANTHROPIC_API_KEY"])
app = FastAPI()

with open("data/transactions.csv") as f:
    ROWS = list(csv.DictReader(f))


def apply_rules(rules: list[dict], narration: str) -> str:
    """The rulebook. Runs in microseconds, costs nothing."""
    text = narration.upper()
    for rule in rules:
        if rule.get("keyword", "").upper() in text:
            return rule.get("category", "Uncategorised")
    return "Uncategorised"


def score(rules: list[dict]):
    """The verifier. Deterministic, external, free."""
    wrong = []
    for row in ROWS:
        predicted = apply_rules(rules, row["narration"])
        if predicted != row["category"]:
            wrong.append({"narration": row["narration"],
                          "predicted": predicted, "correct": row["category"]})
    return (len(ROWS) - len(wrong)) / len(ROWS), wrong


def build_prompt(wrong: list[dict] | None) -> str:
    """Fresh every step. Never grows."""
    if wrong is None:
        samples = [r["narration"] for r in ROWS[:6]]
        return (f"Categories: {', '.join(CATEGORIES)}\n"
                f"Example narrations: {samples}\n"
                "Write a rulebook covering Indian card statement narrations.")
    lines = [f"- {w['narration']!r} → you said {w['predicted']}, should be {w['correct']}"
             for w in wrong[:6]]
    return ("Your rulebook got these wrong:\n" + "\n".join(lines) +
            "\nReturn the full corrected rulebook.")


@app.post("/run")
def run():
    trace, seen = [], set()
    rules, wrong = [], None
    total_in = total_out = 0

    for step in range(1, MAX_STEPS + 1):
        prompt = build_prompt(wrong)
        response = client.messages.create(
            model=MODEL, max_tokens=MAX_TOKENS, system=SYSTEM,
            messages=[{"role": "user", "content": prompt}],
        )
        total_in += response.usage.input_tokens
        total_out += response.usage.output_tokens

        raw = response.content[0].text.strip().strip("`")
        try:
            rules = json.loads(raw[raw.index("["):raw.rindex("]") + 1])
        except (ValueError, json.JSONDecodeError):
            trace.append({"step": step, "error": "model did not return valid JSON",
                          "tokens_in": response.usage.input_tokens,
                          "tokens_out": response.usage.output_tokens})
            continue

        accuracy, wrong = score(rules)
        trace.append({
            "step": step, "accuracy": round(accuracy, 3), "rule_count": len(rules),
            "wrong": wrong[:6], "prompt": prompt,
            "tokens_in": response.usage.input_tokens,
            "tokens_out": response.usage.output_tokens,
        })

        if accuracy >= TARGET:
            return finish("verified", rules, trace, total_in, total_out)

        # No-progress exit: identical rulebook twice means it is circling.
        fingerprint = json.dumps(rules, sort_keys=True)
        if fingerprint in seen:
            return finish("no_progress", rules, trace, total_in, total_out)
        seen.add(fingerprint)

    return finish("step_cap", rules, trace, total_in, total_out)


def finish(outcome, rules, trace, total_in, total_out):
    with open("rulebook.json", "w") as f:
        json.dump(rules, f, indent=2)
    return {"outcome": outcome, "rules": rules, "trace": trace,
            "tokens_in": total_in, "tokens_out": total_out}


@app.get("/categorise")
def categorise(narration: str):
    """Uses the saved rulebook. No model call. Zero tokens."""
    try:
        with open("rulebook.json") as f:
            rules = json.load(f)
    except FileNotFoundError:
        return {"category": None, "note": "Run the loop first to build a rulebook."}
    return {"category": apply_rules(rules, narration)}


app.mount("/static", StaticFiles(directory="static"), name="static")


@app.get("/")
def index():
    return FileResponse("static/index.html")
